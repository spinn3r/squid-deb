extern heap_key HeapKeyGen_StoreEntry_LFUDA(void *entry, double age);
extern heap_key HeapKeyGen_StoreEntry_GDSF(void *entry, double age);
extern heap_key HeapKeyGen_StoreEntry_LRU(void *entry, double age);
