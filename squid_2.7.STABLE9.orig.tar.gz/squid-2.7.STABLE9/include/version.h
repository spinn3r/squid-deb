/*
 * $Id: version.h,v 1.133 2001/08/31 11:19:09 robertc Exp $
 *
 *  SQUID_VERSION - String for version id of this distribution
 */

/*
 * SQUID_VERSION is now the automake "VERSION" string.
 */

#ifndef SQUID_RELEASE_TIME
#define SQUID_RELEASE_TIME 1268784602
#endif
